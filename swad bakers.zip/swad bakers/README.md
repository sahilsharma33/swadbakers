# Swad Bakers

Swad Bakers — Local bakery & delivery platform (starter scaffold)

This repository contains a full-stack scaffold for Swad Bakers:
- Frontend: Plain HTML/CSS/Vanilla JS (frontend/)
- Backend: Node.js + Express + MongoDB (backend/)
- Python worker: a small script to simulate order progress (worker/)

Features:
- Landing page with background video
- Categories, product listing, search & filters
- Product details, cart, multi-step checkout (Razorpay server-side integration)
- JWT auth (register/login)
- City & service area management
- Orders, order tracking, admin endpoints
- Admin SPA (basic)
- Seed script to populate sample data

Important
- Razorpay keys and other secrets MUST be provided via environment variables — do NOT commit secrets.

Quickstart (development)

1. Install MongoDB and ensure it's running locally.
2. Backend
   - cd backend
   - cp .env.example .env and edit values (MONGODB_URI, JWT_SECRET, RZP_KEY_ID, RZP_KEY_SECRET, FRONTEND_URL)
   - npm install
   - npm run seed    # creates admin user (admin@swadbakers.local / adminpass) and sample data
   - npm run dev     # runs backend on PORT (default 5000)

3. Frontend
   - Serve the frontend folder with a static server or open frontend/index.html directly in browser.
   - The frontend expects the backend API at http://localhost:5000/api (change API_BASE in frontend/js/api.js if needed).

4. Admin
   - Login with seeded admin user at /api/auth/login to obtain a JWT for admin APIs.
   - Use admin.html for a basic admin UI (it uses api endpoints; get token from login flow).

5. Python worker (optional)
   - export ADMIN_TOKEN="Bearer <admin_jwt>" and API_BASE if different
   - python3 worker/worker.py

Environment variables
- See backend/.env.example

Razorpay
- For production, use live Razorpay credentials and implement webhook verification with proper security and idempotency handling. Do not place secret keys in frontend.

Next steps & improvements
- Add full checkout UI (client-side collecting payment details) and integrate the Razorpay checkout widget with server-created orders.
- Improve admin UI (product image uploads, category management).
- Add email notifications (transactional) for order events.
- Replace static assets with optimized images & compressed videos.
- Add unit & integration tests.
- Add deployment scripts (Docker, Kubernetes, or a simple VPS + pm2 setup).

License: MIT (starter scaffold)