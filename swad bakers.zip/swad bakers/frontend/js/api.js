// Simple API wrapper
const API_BASE = window.API_BASE || 'http://localhost:5002/api';

export async function api(path, opts = {}) {
  const token = localStorage.getItem('swad_token');
  const headers = opts.headers || {};
  headers['Content-Type'] = headers['Content-Type'] || 'application/json';
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch(API_BASE + path, {...opts, headers});
  const json = await res.json().catch(() => null);
  if (!res.ok) throw {status: res.status, body: json};
  return json;
}