import { api } from './api.js';

const cache = { categories: [], products: [], cities: [] };

async function init() {
  document.getElementById('year').textContent = new Date().getFullYear();
  await loadCategories();
  await loadCities();
  await loadProducts();
  bindUI();
  renderCategories();
  renderProducts();
}

function bindUI() {
  document.getElementById('order-now').addEventListener('click', ()=> location.href = '#products-section');
  document.getElementById('explore-menu').addEventListener('click', ()=> location.href = '#products-section');
  document.getElementById('search').addEventListener('input', renderProducts);
  document.getElementById('filter-category').addEventListener('change', renderProducts);
  document.getElementById('sort').addEventListener('change', renderProducts);
  document.getElementById('btn-login').addEventListener('click', ()=> location.href = 'login.html');
  document.getElementById('btn-cart').addEventListener('click', ()=> location.href = 'cart.html');
  const citySelect = document.getElementById('city-select');
  citySelect.addEventListener('change', ()=> {
    const sel = citySelect.value;
    const city = cache.cities.find(c=>c._id===sel);
    if(city) {
      document.getElementById('city-name').textContent = city.name;
      localStorage.setItem('swad_city', JSON.stringify(city));
    }
  });
}

async function loadCategories(){
  try {
    const res = await api('/categories');
    cache.categories = res;
    const sel = document.getElementById('filter-category');
    sel.innerHTML = '<option value="">All</option>';
    res.forEach(c=> sel.insertAdjacentHTML('beforeend', `<option value="${c._id}">${c.name}</option>`));
  } catch(e){
    console.error(e);
  }
}
async function loadCities(){
  try {
    const res = await api('/cities');
    cache.cities = res;
    const csel = document.getElementById('city-select');
    csel.innerHTML = '';
    res.forEach(c=> csel.insertAdjacentHTML('beforeend', `<option value="${c._id}">${c.name}</option>`));
    // set saved
    const saved = JSON.parse(localStorage.getItem('swad_city')||'null');
    if(saved) {
      document.getElementById('city-name').textContent = saved.name;
      csel.value = saved._id;
    }
  } catch(e){ console.error(e) }
}

async function loadProducts(){
  try {
    const res = await api('/products');
    cache.products = res;
  } catch(e){ console.error(e) }
}

function renderCategories(){
  const grid = document.getElementById('categories-grid');
  grid.innerHTML = '';
  cache.categories.forEach(c=>{
    const el = document.createElement('div');
    el.className = 'category-card';
    el.innerHTML = `<strong>${c.name}</strong><p class="muted">${c.description || ''}</p>`;
    el.addEventListener('click', ()=> {
      document.getElementById('filter-category').value = c._id;
      renderProducts();
      location.href = '#products-section';
    });
    grid.appendChild(el);
  });
}

function renderProducts(){
  const q = document.getElementById('search').value.trim().toLowerCase();
  const cat = document.getElementById('filter-category').value;
  const sort = document.getElementById('sort').value;
  let items = cache.products.slice();
  if (q) items = items.filter(p=> (p.name + ' ' + (p.description||'')).toLowerCase().includes(q));
  if (cat) items = items.filter(p=> p.category && p.category._id === cat);
  if (sort === 'price_asc') items.sort((a,b)=>a.price - b.price);
  if (sort === 'price_desc') items.sort((a,b)=>b.price - a.price);
  if (sort === 'rating_desc') items.sort((a,b)=> (b.rating||0) - (a.rating||0));
  const grid = document.getElementById('products-grid');
  grid.innerHTML = '';
  const tpl = document.getElementById('product-card');
  items.forEach(p=>{
    const node = tpl.content.cloneNode(true);
    node.querySelector('img').src = p.image || 'https://via.placeholder.com/600x400?text=Product';
    node.querySelector('img').alt = p.name;
    node.querySelector('.title').textContent = p.name;
    node.querySelector('.meta').textContent = `${p.category?.name || ''} • ${p.deliveryTime || '30-45 min'}`;
    node.querySelector('.price-val').textContent = p.price.toFixed(0);
    const addBtn = node.querySelector('.add-cart');
    addBtn.addEventListener('click', ()=> {
      addToCart(p);
    });
    grid.appendChild(node);
  });
}

function addToCart(product){
  const cart = JSON.parse(localStorage.getItem('swad_cart')||'[]');
  const found = cart.find(i=>i._id===product._id);
  if(found) found.qty++;
  else cart.push({...product, qty:1});
  localStorage.setItem('swad_cart', JSON.stringify(cart));
  document.getElementById('cart-count').textContent = cart.reduce((s,i)=>s+i.qty,0);
  alert('Added to cart');
}

window.addEventListener('load', init);