import { api } from './api.js';

const form = document.getElementById('auth-form');
const toggle = document.getElementById('btn-toggle');
const email = document.getElementById('email');
const password = document.getElementById('password');
const msg = document.getElementById('auth-msg');

let mode = 'login';
toggle.addEventListener('click', ()=> {
  mode = mode === 'login' ? 'register' : 'login';
  toggle.textContent = mode === 'login' ? 'Create account' : 'Have an account? Login';
});

form.addEventListener('submit', async (e)=> {
  e.preventDefault();
  const payload = { email: email.value.trim(), password: password.value };
  try {
    let res;
    if (mode === 'login') res = await api('/auth/login', {method:'POST', body: JSON.stringify(payload)});
    else res = await api('/auth/register', {method:'POST', body: JSON.stringify(payload)});
    localStorage.setItem('swad_token', res.token);
    localStorage.setItem('swad_user', JSON.stringify(res.user));
    msg.textContent = 'Success. Redirecting...';
    setTimeout(()=> location.href = '/', 700);
  } catch (err) {
    msg.textContent = err?.body?.message || 'An error occurred';
  }
});