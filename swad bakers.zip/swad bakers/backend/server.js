require('dotenv').config();
const express = require('express');
const connectDB = require('./config/db');
const cors = require('cors');
const morgan = require('morgan');
const app = express();
const PORT = process.env.PORT || 5002;

connectDB(process.env.MONGODB_URI).catch(err => { console.error(err); process.exit(1); });

app.use(cors({ origin: process.env.FRONTEND_URL || '*' }));
app.use(express.json());
app.use(morgan('dev'));

// API routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/categories', require('./routes/categories'));
app.use('/api/cities', require('./routes/cities'));
app.use('/api/orders', require('./routes/orders'));
app.use('/api/admin', require('./routes/admin'));
// Serve frontend static (optional): if you want backend to serve frontend, put built frontend files into backend/public
app.use(express.static('../frontend')); // during development, this path will serve frontend files

app.get('/', (req,res)=> res.sendFile(require('path').resolve(__dirname, '../frontend/index.html')));

// error handler
app.use((err,req,res,next)=>{
  console.error(err);
  res.status(500).json({message:'Server error'});
});

app.listen(PORT, ()=> {
  console.log('Server running on port', PORT);
});